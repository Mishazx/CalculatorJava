import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Console cli = new Console();
        cli.MainMenu();
    }
}